from django.urls import path
from .views import predict_toxicity, get_dataset_chemicals

urlpatterns = [
    path('predict/', predict_toxicity, name='predict_toxicity'),
    path('dataset-chemicals/', get_dataset_chemicals, name='get_dataset_chemicals'),
]
